-- phpMyAdmin SQL Dump
-- version 4.9.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Apr 09, 2022 at 08:44 AM
-- Server version: 10.4.10-MariaDB
-- PHP Version: 7.3.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `pnj_task`
--

-- --------------------------------------------------------

--
-- Table structure for table `student_user`
--

DROP TABLE IF EXISTS `student_user`;
CREATE TABLE IF NOT EXISTS `student_user` (
  `id` int(255) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  `email` varchar(200) NOT NULL,
  `phone` varchar(12) NOT NULL,
  `image` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student_user`
--

INSERT INTO `student_user` (`id`, `name`, `email`, `phone`, `image`, `password`, `created_at`) VALUES
(4, 'prem dass', 'dasprem1999@gmail.com', '8130674505', NULL, '$2y$10$tc7OzCU7wz2Cq0a1Qmo4wuKx5m1QfCM1o94YuG2TI9RFVd5HDkg9G', '2022-04-09 06:47:37'),
(5, 'prem das', 'prem1999@gmail.com', '8130674504', NULL, '$2y$10$T/Tog6mq1x0TMShWm9tqCOVBevWNXpyHdtIjJfTRBw3CggadlAQoK', '2022-04-09 06:50:12'),
(6, 'prem das', 'deco@gmail.com', '8130674508', NULL, '$2y$10$u0jhXEjV2SMAq5Qn8tAYDOV7D8mwwYDSLVa7/DTiaMW5uYQCP8HX.', '2022-04-09 07:19:49'),
(7, 'prem das', 'das1999@gmail.com', '8130674509', NULL, '$2y$10$5nVLKS2R2gJks1wEIJ/gi.RapGWNL7KVxe3U52VKcoJ2tbKRhIDD.', '2022-04-09 07:20:42'),
(8, 'prem', 'dsprem1999@gmail.com', '8130674500', NULL, '$2y$10$vlmqampLqmLBjXQQrgR8NOwEuWQhc6fpbl5D6KQluLLqjF.pVdwA6', '2022-04-09 08:37:45');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
