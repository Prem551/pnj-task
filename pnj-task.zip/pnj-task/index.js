$(document).ready(function($) {

    //sign in form open btn click in index.php page
    $(document).on('click', '#signin_form_open_btn', function() {
        $('#user_signup_section').hide();
        $('#user_login_section').show();
    });

    //sign up form open btn click in index.php page
    $(document).on('click', '#signup_form_open_btn', function() {
        $('#user_login_section').hide();
        $('#user_signup_section').show();
    });


    //AJAX FORM START...
    $(document).on('submit', '.ajaxform', function(e) {
        var x = $(this);
        var url = x.data('url');
        var load = x.data('load');
        var alrt = x.data('alert');
        var rtrn = x.data('rtrn');
        var btn = x.find('button[type="submit"]');
        var xbtn = btn.html();
        if (url == undefined) {
            url = '';
        }
        if (load == undefined) {
            load = 'url';
        }
        if (alrt == undefined) {
            alrt = '';
        }
        if (rtrn == undefined) {
            rtrn = '';
        }
        $.ajax({
            type: 'POST',
            url: 'submit.php',
            data: x.serialize(),
            beforeSend: function() {
                btn.html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Verifying...').prop('disabled', true);
            },
            success: function(sms) {
                if (sms == rtrn) {
                    btn.html(sms);
                    if (alrt == 'yes') {
                        swal("", sms, "success");
                        btn.html(xbtn).prop('disabled', false);
                    }
                    if (load == 'ajax') {
                        page_loader(location.pathname);
                    } else if (url != '') {
                        window.setTimeout(function() {
                            location.href = url;
                        }, 2000);
                    }
                } else {
                    swal("", sms, "error");
                    btn.html(xbtn).prop('disabled', false);
                }
            },
            error: function(error) {
                btn.html(xbtn).prop('disabled', false);
            }
        })
        return false;
    });
    //AJAX FORM END...

});