<?php
include 'submit.php';

if(isset($_SESSION['cts_studentid']) && $_SESSION['cts_studentid'] != ''){
    $user_id = $_SESSION['cts_studentid'];
}
else{
    ?>
    <script type="text/javascript">
      window.location.href = "index.php"
    </script>
  <?php
}

?>

<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- custom CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Student | Dashboard</title>
</head>

<body class="section-bg">

<section class="mt-3">

<div class="container px-lg-5 px-2">
    <div class="row">
        <div class="col-lg-4 col-12 mt-2">
            <!-- profile card start -->
            <div class="bg-white border-radius-20px">
                <div class="text-center">
                    <h3 class="pt-2" style="text-transform:capitalize;"><?php echo get_info('student_user','name','id',$user_id); ?></h3>
                </div>
                <div class="text-center my-3">
                    <form method="post" enctype="multipart/form-data">
                    <input type="hidden" name="u_user_image_id" value="<?php echo get_info('student_user','id','id',$user_id);?>">
                    <input type="hidden" name="u_user_image_path" value="<?php echo get_info('student_user','image','id',$user_id);?>">
                        <label>
                            <?php
                            $img = get_info('student_user','image','id',$user_id);
                            if($img==''){
                                echo '<img class="img-circle img-fluid rounded-circle" width="90" height="90" style="height: 90px;width: 90px;object-fit: cover;" src="user_blank_pp.png" alt="User Avatar">';
                            }
                            else{
                                echo '<img class="img-circle img-fluid rounded-circle" width="90" height="90" style="height: 90px;width: 90px;object-fit: cover;" src="user_profile_picture/'.$img.'" alt="User Avatar">';
                            }
                            ?>
                            <input type="file" name="image" style="display:none" required="on"  onchange='if(this.value != 0) { this.form.submit(); }'> 
                        </label>
                    </form>
                </div>
                <div class="py-1 bg-light mx-5">
                    <div class="text-center">
                        <b>Registered At</b> 
                        <span class="text-success"><?php echo get_format_date('f1',get_info('student_user','created_at','id',$user_id));?></span>
                    </div>
                    <div class="text-center my-2">
                    <a href="logout.php" class="btn btn-danger btn-sm">Logout</a>
                    </div>
                </div>
            </div>
            <!-- profile card end -->
        </div>
        <div class="col-lg-8 col-12 mt-2">
            <div class="bg-white border-radius-20px p-3">

                <nav>
                    <div class="nav nav-tabs" id="nav-tab" role="tablist">
                        <button class="nav-link active" id="nav-home-tab" data-bs-toggle="tab" data-bs-target="#nav-home" type="button" role="tab" aria-controls="nav-home" aria-selected="true">Profile</button>
                        <button class="nav-link" id="nav-profile-tab" data-bs-toggle="tab" data-bs-target="#nav-profile" type="button" role="tab" aria-controls="nav-profile" aria-selected="false">Password</button>
                    </div>
                </nav>

                <div class="tab-content" id="nav-tabContent">
                    <!-------------------------- profile detail update start ---------------------------->
                    <div class="tab-pane fade show active" id="nav-home" role="tabpanel" aria-labelledby="nav-home-tab">
                            <h4 class="mb-3 font-weight-bold mt-4">Update Profile Details</h4>
                            <hr/>
                            <form class="ajaxform" data-alert="yes" data-rtrn="Updated Successfully">
                                <input type="hidden" name="u_user_id" value="<?php echo get_info('student_user','id','id',$user_id);?>">
                            
                                <div class="form-row">
                                    <div class="col-12 mb-2">
                                        <small>Name</small>
                                        <div class="input-group">
                                            <input type="text" value="<?php echo get_info('student_user','name','id',$user_id);?>" class="form-control" placeholder="User Name" name="u_user_name" required>
                                        </div>
                                    </div>
                                    <div class="col-12 mb-2">
                                        <small>Email</small>
                                        <div class="input-group">
                                            <input type="email" value="<?php echo get_info('student_user','email','id',$user_id);?>" class="form-control" placeholder="User Email" name="u_user_email" required>
                                        </div>
                                    </div>
                                    <div class="col-12 mb-2">
                                        <small>Phone</small>
                                        <div class="input-group">
                                            <input type="number" value="<?php echo get_info('student_user','phone','id',$user_id);?>" class="form-control" placeholder="User Phone" name="u_user_phone" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-12 mb-2 mt-3">
                                    <button type="submit" class="btn btn-primary px-3 btn-sm">Update Profile Details</button>
                                    </div> 
                                </div>
                            </form>
                    </div>
                    <!---------------------- profile detail update end ----------------------->

                    <!------------------ password update start ---------------->
                    <div class="tab-pane fade" id="nav-profile" role="tabpanel" aria-labelledby="nav-profile-tab">
                            <h4 class="mb-3 font-weight-bold mt-4">Update Password</h4>
                            <hr/>
                            <form class="ajaxform" data-alert="yes" data-rtrn="Updated Successfully" data-url="dashboard.php">
                                <input type="hidden" name="u_user_id" value="<?php echo get_info('student_user','id','id',$user_id);?>">
                                <div class="form-row">
                                    <div class="col-lg-6 mb-2">
                                        <small>Old Password</small>
                                        <div class="input-group">
                                            <input type="password" name="u_user_old_pass" class="form-control bg-white" placeholder="Enter old password" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-2">
                                        <small>New Password</small>
                                        <div class="input-group">
                                            <input type="password" name="u_user_new_pass" class="form-control" placeholder="Create new password" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-2">
                                        <small>Confirm New Password</small>
                                        <div class="input-group">
                                            <input type="password" name="u_user_new_cpass" class="form-control" placeholder="Confirm new password" required>
                                        </div>
                                    </div>
                                    <div class="col-lg-6 mb-2 mt-3">
                                        <button type="submit" class="btn btn-primary px-3 btn-sm">Change Password</button>
                                    </div> 
                                </div>
                            </form> 
                    </div>
                    <!--------------------- password update end -------------------->
                </div>

            </div>
        </div>
    </div>
</div>


</section>
    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jquery JS -->
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <!-- custom jquery JS -->
    <script src="index.js"></script>
    <!-- sweat alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</body>

</html>