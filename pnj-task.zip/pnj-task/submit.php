<?php
include 'connection.php';
session_start();
date_default_timezone_set('Asia/Kolkata');
$dt_CT=date("Y-m-d H:i:s");


function get_format_date($formate='f0',$date=''){
    $f1='M d, Y';
    $f2='Y-m-d';
    $f3='F d, Y g:i A';
    if (in_array($formate, ['f1','f2','f3']) && $date!='') {
      return date($$formate, strtotime($date));
    }else{
      return $date;
    }
  }
  function is_valid_input($type='',$value=''){
    if ($type=='name') {
      return (boolean)preg_match("/^[a-zA-Z. ]+$/", $value);
    }elseif ($type=='phone') {
      return (boolean)preg_match("/^[6789]\d{9}$/", $value);
    }elseif ($type=='email') {
      return (boolean)filter_var($value, FILTER_VALIDATE_EMAIL);
    }elseif ($type=='gender') {
      return (boolean)in_array(strtolower($value), ['male','female','other']);
    }elseif ($type=='pan') {
      return (boolean)preg_match("/^([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}$/", $value);
    }elseif ($type=='aadhar') {
      return (boolean)preg_match("/^([0-9]){12}$/", $value);
    }elseif ($type=='gst') {
      return (boolean)preg_match("/^(0[1-9]|[1-2][0-9]|3[0-5])([a-zA-Z]){5}([0-9]){4}([a-zA-Z]){1}([a-zA-Z0-9]){1}([a-zA-Z]){1}([0-9]){1}?$/", $value);
    }elseif ($type=='pincode') {
      return (boolean)preg_match("/^([123456789])\d{5}$/", $value);
    }elseif ($type=='ifsc') {
      return (boolean)preg_match("/^[a-zA-Z]{4}[a-zA-Z0-9]{7}$/", $value);
    }elseif ($type=='upi') {
      return (boolean)preg_match("/^\w+@\w+$/", $value);
    }elseif ($type=='password') {
      return (boolean)preg_match("/^(?=.*\d)(?=.*[A-Za-z])[0-9A-Za-z!@#$%]{8,12}$/", $value);
    }elseif ($type=='strong_password') {
      return (boolean)preg_match("/^(?=.*\d)(?=.*[@#\-_$%^&+=§!\?])(?=.*[a-z])(?=.*[A-Z])[0-9A-Za-z@#\-_$%^&+=§!\?]{8,20}$/", $value);
    }else{
      return false;
    }
  }
  
  // MASTER FUNCTION ===================
  function get_info($table='',$column='',$key='id',$value='1'){
    global $con;
    $query  ="SELECT `".$column."` FROM `".$table."` WHERE `".$key."`='".$value."' ORDER BY `".$key."` DESC LIMIT 1";
    $result = mysqli_query($con,$query);
    if (!$result) {
      return 'Invalid';
    }
    elseif (mysqli_num_rows($result)>0) {
      return mysqli_fetch_assoc($result)[$column];
    }else{
      return 'hjgk';
    }
  }



//user registration
if (isset($_POST['user_name'],$_POST['user_email'],$_POST['user_phone'],$_POST['user_password'],$_POST['user_cpassword'])) {

	$user_name  	    =mysqli_real_escape_string($con,$_POST['user_name']);
	$user_email 	    =mysqli_real_escape_string($con,$_POST['user_email']);
	$user_phone  	    =mysqli_real_escape_string($con,$_POST['user_phone']);
	$user_password  	=mysqli_real_escape_string($con,$_POST['user_password']);
	$user_cpassword 	=mysqli_real_escape_string($con,$_POST['user_cpassword']);

	if (!is_valid_input('name',$user_name) || strlen($user_name)>100) {
		exit('Please enter your valid name');
	}
  elseif (!is_valid_input('phone',$user_phone)) {
		exit('Please enter your valid phone');
	}
	elseif (!is_valid_input('email',$user_email)) {
		exit('Please enter your valid email');
	}
	elseif (mysqli_num_rows(mysqli_query($con,"SELECT `id` FROM `student_user` WHERE `phone`='$user_phone'"))>0) {
		exit('Phone is already exists');
	}
	elseif (mysqli_num_rows(mysqli_query($con,"SELECT `id` FROM `student_user` WHERE `email`='$user_email'"))>0) {
		exit('Email is already exists');
	}
	elseif (strlen($user_password)<8) {
		exit('Password must be at least 8 characters.');
	}
	elseif ($user_password!=$user_cpassword) {
		exit('Password and Confirm Password must be same.');
	}
	else{
		$npass=password_hash($user_password, PASSWORD_DEFAULT);
		mysqli_query($con,"INSERT INTO `student_user`(`name`, `email`, `phone`, `password`, `created_at`) VALUES ('$user_name', '$user_email', '$user_phone', '$npass', '$dt_CT')") or die('Error in register:004.0');
		$id=mysqli_insert_id($con);
		$_SESSION['cts_studentid']=$id;

		echo 'student_registration_success';

	}
}


//user login
if (isset($_POST['user_login_email'],$_POST['user_login_password'])) {
  $email   =mysqli_real_escape_string($con,$_POST['user_login_email']);
  $pass    =mysqli_real_escape_string($con,$_POST['user_login_password']);
  
  $q=mysqli_query($con,"SELECT * from `student_user` where `email`='$email' ");
  if (mysqli_num_rows($q)>0) {
     $row = mysqli_fetch_assoc($q);
     $data_pass=$row['password'];
     if(!password_verify($pass,$data_pass)) {
      exit('Incorrect password!');
     }
     else{
       $_SESSION['cts_studentid']=$row['id'];
       echo 'Login Successfully';
     }  
  }
  else{
     exit('Invalid Email/Password!');
  }
}


//user upload profile picture
if(isset($_FILES['image']['name'],$_POST['u_user_image_id'])){
  $id 	=mysqli_real_escape_string($con,$_POST['u_user_image_id']);
  $img_path 	=mysqli_real_escape_string($con,$_POST['u_user_image_path']);
  $filename = 'user_img_'.time().'.jpeg';

  $location = "user_profile_picture/".$filename;
  $imageFileType = pathinfo($location,PATHINFO_EXTENSION);
  $imageFileType = strtolower($imageFileType);

  $valid_extensions = array("jpg","jpeg","png");
     
  /* Check file extension */
  if(in_array(strtolower($imageFileType), $valid_extensions)) {
     if ($_FILES['image']['size']>1048576) {
     ?>
     <script>
        window.addEventListener('load',function () {
           swal("", "File Size is not more than 01 MB", "error");
        })
     </script>
     <?php
     }
     /* Upload file */
     else{
        if(move_uploaded_file($_FILES['image']['tmp_name'],$location)){

          if($img_path!=''){
            unlink('user_profile_picture/'.$img_path);
          }

        $q=mysqli_query($con,"UPDATE `student_user` SET `image`='$filename' WHERE `id`='$id'") or die('Error in Update:001');
        if ($q) {
           ?>
        <script>
           window.addEventListener('load',function () {
              swal("Profile Picture", "profile is updated!", "success");
           })
        </script>
        <?php
        }
      }
   else{
   ?>
   <script>
      window.addEventListener('load',function () {
         swal("", "File Size is not more than 01 MB", "error");
      })
   </script>
   <?php
   }
     }

  }
else{
  ?>
  <script>
     window.addEventListener('load',function () {
        swal("", "Invalid File Type!", "error");
     })
  </script>
  <?php
  } 

}


//user Profile Update...
if (isset($_POST['u_user_id'],$_POST['u_user_name'],$_POST['u_user_email'],$_POST['u_user_phone'])) {

	$u_user_id    	=mysqli_real_escape_string($con,$_POST['u_user_id']);
	$u_user_name 	  =mysqli_real_escape_string($con,$_POST['u_user_name']);
  $u_user_email   =mysqli_real_escape_string($con,$_POST['u_user_email']);
	$u_user_phone   =mysqli_real_escape_string($con,$_POST['u_user_phone']);

	if (!is_valid_input('name',$u_user_name) || strlen($u_user_name)>100) {
		exit('Please enter your valid name');
	}
	elseif (!is_valid_input('email',$u_user_email)) {
		exit('Please enter your valid email');
	}
  elseif (!is_valid_input('phone',$u_user_phone)) {
		exit('Please enter your valid phone');
	}
  elseif (mysqli_num_rows(mysqli_query($con,"SELECT `id` FROM `student_user` WHERE `phone`='$u_user_phone' AND `id`!='$u_user_id' "))>0) {
		exit('Phone is already exists');
	}
	elseif (mysqli_num_rows(mysqli_query($con,"SELECT `id` FROM `student_user` WHERE `email`='$u_user_email' AND `id`!='$u_user_id' "))>0) {
		exit('Email is already exists');
	}
	else{
    mysqli_query($con,"UPDATE `student_user` SET `name`='$u_user_name', `email`='$u_user_email',`phone`='$u_user_phone'  WHERE `id`='$u_user_id'");
     echo 'Updated Successfully';
	}
}

//user Password Update...
if (isset($_POST['u_user_id'],$_POST['u_user_old_pass'],$_POST['u_user_new_pass'],$_POST['u_user_new_cpass'])) {
	$u_user_id        =mysqli_real_escape_string($con,$_POST['u_user_id']);
	$u_user_old_pass  =mysqli_real_escape_string($con,$_POST['u_user_old_pass']);
	$u_user_new_pass  =mysqli_real_escape_string($con,$_POST['u_user_new_pass']);
  $u_user_new_cpass  =mysqli_real_escape_string($con,$_POST['u_user_new_cpass']);
	
	if (!is_valid_input('password',$u_user_old_pass)) {
		exit('Please enter valid old password');
	}
	elseif (!is_valid_input('password',$u_user_new_pass)) {
		exit('Please enter valid new password');
	}
	elseif ($u_user_new_pass!=$u_user_new_cpass) {
		exit('Password and Confirm Password must be same');
	}
	elseif ($u_user_old_pass==$u_user_new_cpass) {
		exit('Old Password and New Password must be deferent');
	}else{
		$query=mysqli_query($con,"SELECT * FROM `student_user` WHERE `id`='$u_user_id' ");
		if (mysqli_num_rows($query)>0) {
			$r=mysqli_fetch_assoc($query);
			if (password_verify($u_user_old_pass, $r['password'])) {
				$hpass=password_hash($u_user_new_pass, PASSWORD_DEFAULT);
				mysqli_query($con,"UPDATE `student_user` SET `password`='$hpass' WHERE `id`='$u_user_id'");
				echo 'Updated Successfully';
			}
			else{
				exit('Incorrect old password');
			}
		}else{
			exit('User Not Found');
		}
	}
}



?>