<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- custom CSS -->
    <link rel="stylesheet" href="style.css">
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <title>Student | Login</title>
</head>
<body>

<section class="bg-overlay">

    <div class="container" style="margin-top:80px;">
        <div class="row justify-content-center">
            <div class="col-xl-4 col-lg-6 col-md-8" id="user_signup_section">
                <div class="bg-white p-3 border-radius-20px">
                    <h1 class="text-dark mt-2 text-center font-weight-bold">Create acount</h1>
                    <p class="mb-4 text-center text-dark">Already have an account? <a href="javascript:void(0)" id="signin_form_open_btn">Sign in</a></p>
                    <form class="px-3" id="user_signup_form" enctype="multipart/form-data">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <input type="text" name="user_name" data-error="#error-name" class="form-control" placeholder="Enter fullname">
                                    <small class="error text-danger font-12 font-italic" id="error-name"></small>
                                </div>
                                <div class="mb-3">
                                    <input type="email" name="user_email" data-error="#error-email" class="form-control" placeholder="Enter email">
                                    <small class="error text-danger font-12 font-italic" id="error-email"></small>
                                </div>
                                <div class="mb-3">
                                    <input type="number" name="user_phone" data-error="#error-phone" class="form-control" placeholder="Enter mobile">
                                    <small class="error text-danger font-12 font-italic" id="error-phone"></small>
                                </div>
                                <div class="mb-3">
                                    <input type="password" name="user_password" data-error="#error-pass" class="form-control" placeholder="Enter password" id="u_pass"/>
                                    <small class="error text-danger font-12 font-italic" id="error-pass"></small>
                                </div>
                                <div class="mb-3">
                                    <input type="password" name="user_cpassword" data-error="#error-cpass" class="form-control" placeholder="Enter confirm password">
                                    <small class="error text-danger font-12 font-italic" id="error-cpass"></small>
                                </div>
                                <div class="my-3">
                                    <button class="py-2 btn-primary col-12 border-radius-10px" type="submit">Sign up</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
            <div class="col-xl-4 col-lg-6 col-md-8" id="user_login_section" style="display: none;margin-top: 120px;">
                <div class="bg-white p-3 border-radius-20px">
                    <h1 class="text-dark mt-2 text-center font-weight-bold">Login acount</h1>
                    <p class="mb-4 text-center text-dark">Don't have an account? <a href="javascript:void(0)" id="signup_form_open_btn">Sign up</a></p>
                    <form class="px-3 ajaxform" data-alert="yes" data-rtrn="Login Successfully" data-url="dashboard.php">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="mb-3">
                                    <input type="email" name="user_login_email" class="form-control" placeholder="Enter email" required>
                                </div>
                                <div class="mb-3">
                                    <input type="password" name="user_login_password" class="form-control" placeholder="Enter password" required>
                                </div>
                                <div class="my-3">
                                    <button class="py-2 btn-primary col-12 border-radius-10px" type="submit">Sign in</button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

</section>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <!-- jquery JS -->
    <script src="node_modules/jquery/dist/jquery.min.js"></script>
    <!-- jquery form validation -->
    <script src="node_modules/jquery-validation/dist/jquery.validate.min.js"></script>
    <script src="node_modules/jquery-validation//dist/additional-methods.min.js"></script>
    <!-- custom jquery JS -->
    <script src="index.js"></script>
    <!-- sweat alert -->
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>

    <script>
        //user registration form start

        $(document).ready(function() {

            $.validator.addMethod("StrongPass", function(value) {
                return /^(?=.*\d)(?=.*[a-zA-Z])(?!.*\s).*$/.test(value);
            }, "Character and Number required");

            $.validator.addMethod("phoneIN", function(value) {
                return /^[6-9]\d{9}$/.test(value);
            }, "Please enter the correct phone number");

            $("#user_signup_form").validate({
                rules: {
                    user_name: {
                        required: true,
                        minlength: 3,
                        maxlength: 100
                    },
                    user_email: {
                        required: true
                    },
                    user_phone: {
                        required: true,
                        nowhitespace: true,
                        phoneIN: true
                    },
                    user_password: {
                        required: true,
                        StrongPass: true,
                        minlength: 8
                    },
                    user_cpassword: {
                        equalTo: '#u_pass',
                        minlength: 8,
                        required: true,
                        StrongPass: true
                    }
                },
                errorPlacement: function(error, element) {
                    var placement = $(element).data('error');
                    if (placement) {
                        $(placement).append(error)
                    } else {
                        error.insertAfter(element);
                    }
                },
                submitHandler: function(form) {
                            $.ajax({
                                type: "POST",
                                url: "submit.php",
                                data: $(form).serialize(),
                                beforeSend: function() {
                                $(form).find('button[type="submit"]').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Verifying').prop('disabled', true);
                                },
                                success: function(respons) {
                                    var respons = respons.trim();
                                    if (respons == 'student_registration_success') {
                                        $(user_signup_form).html("<div id='message' class='px-3 py-3'>");
                                        $('#message').html("<h4 class='text-center text-danger font-weight-bold'>You have successfully sign Up!</h4><p class='text-center' style='color:rgba(0,0,0,0.3);'>Please wait while redirecting to the dashboard page...</p>");
                                        window.setTimeout(function() {
                                            location.href = "dashboard.php";
                                        }, 2500);
                                    } else {
                                        swal("", respons, "error");
                                        $(form).find('button[type="submit"]').html('Sign In').prop('disabled', false);
                                    }
                                }
                            });
                            return false;
                }

            });

        });

        //user registration form end
    </script>
</body>
</html>
